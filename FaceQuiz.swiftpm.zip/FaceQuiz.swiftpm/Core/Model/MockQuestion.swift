//
//  MockQuestion.swift
//  FaceQuiz
//
//  Created by Rodrigo Soares on 10/02/25.
//

import Foundation

struct MockQuestion: Codable {
    let imageName: String
    let difficulty: String
}
